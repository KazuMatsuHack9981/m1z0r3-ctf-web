<html>
	<body>
    <div>
      <h3>this is Japanese page</h3>
		</div>
	</body>
</html>
